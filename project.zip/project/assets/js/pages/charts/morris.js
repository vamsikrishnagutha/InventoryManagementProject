'use strict';
$(function () {
    
    getMorris('donut', 'donut_chart');
});


function getMorris(type, element) {
    if (type === 'donut') {
        Morris.Donut({
            element: element,
            data: [{
                label: 'Total Receivable %',
                value: 10
            }, {
                label: 'Total Received Amount %',
                value: 30
            }, {
                label: 'Total Discount Given %',
                value: 15
            }, 
            {
                label: 'Total Revenue %',
                value: 45
            }],
            colors: ['rgb(252, 19, 3)', 'rgb(21, 25, 214)', 'rgb(242, 130, 17)', 'rgb(53, 128, 38)'],
            formatter: function (y) {
                return y + '%'
            }
        });
    }
}
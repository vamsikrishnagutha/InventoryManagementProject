'use strict';

$(document).ready(function () {
  $('.collapsible').collapsible();
});

